#!/usr/bin/python

import numpy as _np
import matplotlib.pyplot as _plt
import ester_wrap as _wrapper

SIG_SB = 5.670400e-5;
K_BOL = 1.3806503e-16;
HYDROGEN_MASS = 1.67353249e-24;
A_RAD = 7.565767e-15;
GRAV = 6.67384e-8;
C_LIGHT = 2.99792458e10;

M_SUN = 1.9891e33;
R_SUN = 6.95508e10;
L_SUN = 3.8396e33;


def _to_numpy(s, name, nr, nth):
    cmd = 'ptr = s.%s' % name
    exec(cmd)
    tmp = _wrapper.doubleArray_frompointer(ptr.data())
    field = _np.zeros(shape=(nr, nth))
    for ir in range(0, nr):
        for it in range(0, nth):
            field[ir, it] = tmp[it*nr + ir]
    return field

def _mat_to_numpy(mat, nr, nth):
    tmp = _wrapper.doubleArray_frompointer(mat.data())
    field = _np.zeros(shape=(nr, nth))
    for ir in range(0, nr):
        for it in range(0, nth):
            field[ir, it] = tmp[it*nr + ir]
    return field

class star2d:
    def __init__(self, model):

        self.s = _wrapper.star2d()

        if self.s.read(model):
            raise Exception('Failed reading `%s\'' % model)

        self.nr = self.s.nr
        self.nth = self.s.nth
        self.nex = self.s.nex
        self.ndomains = self.s.ndomains

        self.opa = self.s.opa.name
        self.eos = self.s.eos.name
        self.nuc = self.s.nuc.name

        self.z     = _to_numpy(self.s, 'z', self.nr, 1)
        self.G     = _to_numpy(self.s, 'G', self.nr, self.nth)
        self.N2    = _to_numpy(self.s, 'N2()', self.nr, self.nth)
        self.R     = _to_numpy(self.s, 'map.R', self.ndomains+1, self.nth)
        self.T     = _to_numpy(self.s, 'T', self.nr, self.nth)
        self.X     = _to_numpy(self.s, 'comp.X()', self.nr, self.nth)
        self.Y     = _to_numpy(self.s, 'comp.Y()', self.nr, self.nth)
        self.Z     = _to_numpy(self.s, 'comp.Z()', self.nr, self.nth)
        self.eps   = _to_numpy(self.s, 'nuc.eps', self.nr, self.nth)
        self.p     = _to_numpy(self.s, 'p', self.nr, self.nth)
        self.phi   = _to_numpy(self.s, 'phi', self.nr, self.nth)
        self.phiex = _to_numpy(self.s, 'phiex', self.nex, self.nth)
        self.r     = _to_numpy(self.s, 'r', self.nr, self.nth)
        self.rho   = _to_numpy(self.s, 'rho', self.nr, self.nth)
        self.th    = _to_numpy(self.s, 'th', 1, self.nth)
        self.w     = _to_numpy(self.s, 'w', self.nr, self.nth)

        ones = _wrapper.ones(1, self.nth)
        te = _wrapper.zeros(self.nth, 1)
        self.s.map.leg.eval_00(ones, _np.pi/2, te)
        self.Te     = _mat_to_numpy(te, self.nth, 1)

        tp = _wrapper.zeros(self.nth, 1)
        self.s.map.leg.eval_00(ones, 0, tp)
        self.Tp     = _mat_to_numpy(tp, self.nth, 1)
