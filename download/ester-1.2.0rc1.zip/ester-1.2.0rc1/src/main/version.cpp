#include "ester-config.h"
#include "stdio.h"

int main() {
	printf("ESTER %s\n", PACKAGE_VERSION);
    return 0;
}
