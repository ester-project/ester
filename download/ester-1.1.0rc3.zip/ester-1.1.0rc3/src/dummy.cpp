int ester_dummy_symbol;
